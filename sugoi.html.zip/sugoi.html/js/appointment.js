document.getElementById("appointmentForm").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Appointment request submitted!");
});
